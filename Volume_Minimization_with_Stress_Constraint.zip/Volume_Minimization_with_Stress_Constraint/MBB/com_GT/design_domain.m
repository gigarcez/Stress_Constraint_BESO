function [N_designD,node_N_designD,dof_designD] = design_domain(Lx,Ly,Nelx,inci,conectivity,coord,Forcas,caso)

nnos = size(coord,1); 
nel = length(inci(:,1)); 
id = reshape(1:2*nnos,2,nnos);


no_central = find(coord(:,2)==Lx/2 & coord(:,3)==0);

elem_central  = [find(inci(:,3)==no_central);find(inci(:,4)==no_central);find(inci(:,5)==no_central);find(inci(:,6)==no_central)];

N_designD2 = 0;

linha_1 = sort([ elem_central(2) (elem_central(2))-1 (elem_central(2))-2 (elem_central(2))-3 (elem_central(2))-4 (elem_central(1)) (elem_central(1))+1 (elem_central(1))+2 (elem_central(1))+3 (elem_central(1))+4]);

for i=1:10 
    
 N_designD2 = nonzeros(([N_designD2' linha_1 linha_1(i+1:end-i)+(2*i)*Nelx]));
 
end  

N_designD1 = N_designD2 + Nelx;

N_designD = sort(nonzeros(unique([N_designD1;N_designD2; linha_1'])));


% figure(1); 
% clf % limpa a figura
% patch('Faces',inci(1:nel,3:6),'Vertices',coord(:,2:3),'FaceColor','g')
% hold on
% patch('Faces',inci(N_designD,3:6),'Vertices',coord(:,2:3),'FaceColor','k')

axis([-0.10*Lx Lx*1.10 -Ly*0.10 Ly*1.10])
axis equal

 mat = ones(nel,1);
 mat(N_designD) = 5;

node_list = (1:size(coord,1));
node_N_designD = unique(conectivity(mat==5,2:end))';
 
% id apenas dos elemento design domain
dof_designD = id(1:2,setdiff(node_list,node_N_designD)); % id apenas dos elementos design domain

end
