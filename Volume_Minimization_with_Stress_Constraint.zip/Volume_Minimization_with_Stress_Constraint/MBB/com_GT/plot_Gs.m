function  plot_Gs(Gs,ite,V,Pn_factor)



figure('Name','Gap parameter  and Volume fraction ','NumberTitle','off');
%figure('Name','','NumberTitle','off');

%[AX,H1,H2]=plotyy(1:ite,Vc,1:ite,V(2:end)*100);
%[V(ite+1);Vc(ite)]
if Pn_factor==6
[AX,H1,H2]=plotyy(1:(ite-1),Gs(1:(end-1)),1:(ite-1),V(2:(end-1))*100);
else
[AX,H1,H2]=plotyy(1:ite,Gs,1:ite,V(2:end)*100);
end


set(AX,{'ycolor'},{'k';'k'}); legend('Gs','Volume fraction')
set(get(AX(1),'Ylabel'),'String','Gs');
set(get(AX(2),'Ylabel'),'String','Volume fraction (V/V_i)');

%set(AX(1),'YLim',[1.1*min(Gs) 1.0*max(Gs)])
%set(AX(1),'YTick',linspace(1.1*min(Gs),1.0*max(Gs),11))

set(AX(1),'YLim',[-45 1.0*max(Gs)])
set(AX(1),'YTick',linspace(-45,1.0*max(Gs),11))
set(AX(2),'YLim',[0 100]); set(AX(2),'YTick',0:10:100);


%xlabel('Iteration'); title('\fontsize{13}P-norm Stress and Volume fraction')
set(H1,'LineStyle','-','Marker','*');set(H2,'LineStyle','-','Marker','d');

grid on

 tiy = get(gca,'ytick')';
 set(gca,'yticklabel',num2str(tiy,'%.2f'))

end