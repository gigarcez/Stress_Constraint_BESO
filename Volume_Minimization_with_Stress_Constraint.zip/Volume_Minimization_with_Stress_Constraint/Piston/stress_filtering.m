function [Xnew] = stress_filtering(nel,x_min,Xnew,VM_stress,crust_all,crust_inicial)

%alphaS_min = 0.003*(mean(nonzeros(VM_stress)));
alphaS_min = 0.004*(mean(nonzeros(VM_stress)));

smooth = 0;
 for i= 1:nel    
       if VM_stress(i) < alphaS_min  
         smooth = [smooth;i];
       else
       end
 end 

 smooth= unique(nonzeros(smooth));
 
%  crust_all_2 = setdiff(crust_all,crust_inicial);
% 
%  smooth = intersect(smooth,crust_all_2);
 
 Xnew(smooth) = x_min;  


end