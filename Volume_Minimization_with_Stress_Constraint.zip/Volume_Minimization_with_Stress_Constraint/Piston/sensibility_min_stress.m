function [alpha_e_completo,alpha_e,alpha_e_simp,Y,dY,Y_UKU,dY_UKU,UKU,FD_MATRIX_NEW] = sensibility_min_stress(ite,VETOR_MALHA,coord,inci,conectivity,U,Xnew,p,LAMBDA,Ke,Fg,NORMA_P,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM,D,B,elements_boundary,Xb,Xb_old,elside,Po,A,Pn_factor,FD_MATRIX_OLD,V_elem,rho,g)
q=p;

nnos = size(coord,1); 
nel = length(inci(:,1)); 
id = reshape(1:2*nnos,2,nnos);
alpha_e = zeros(nel,1);

Nelx = VETOR_MALHA(1,4);
Nely = VETOR_MALHA(1,5);

Lx = VETOR_MALHA(1,1);
Ly = VETOR_MALHA(1,2);
Lz = VETOR_MALHA(1,3);

 %% Localiza��o do vetor bin�rio que determina se o elemento pertence a borda
 
for i=1:nel
    
pos=[id(1,inci(i,3)) id(2,inci(i,3)) id(1,inci(i,4)) id(2,inci(i,4)) id(1,inci(i,5)) id(2,inci(i,5)) id(1,inci(i,6)) id(2,inci(i,6))]; %

Ue = (U(pos));

LAMBDA_elem = LAMBDA(pos);

UKU(i,1) = Ue'*Ke*Ue;

%% Peso pr�prio

 Ft= [0,-1/4,0,-1/4,0,-1/4,0,-1/4]; % divide a forca peso entre os 4 n�s 

%% Carga Uniformemente distribuida

%        if  Xb(i,1)==1 
%            
%         % [Fpressure_e]=Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A); 
%         
%         % Sliding force:  
%         [Fpressure_e]=DELTA_Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A);
%         
%         delta_Fd = Fpressure_e'; 
%         
%         FD_MATRIX_NEW (1:8,i)= Fpressure_e'; 
%
%        elseif  Xb(i,1)~=1 && Xb_old(i,1)==1

       if  Xb(i,1)~=1 && Xb_old(i,1)==1
            
       % [Fpressure_e]=Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A);  
        
       % Sliding force:  
        [Fpressure_e]=DELTA_Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A);
        
       %  Fd=Fpressure_e;
        
        FD_MATRIX_NEW (1:8,i)= Fpressure_e'; 
         
                     if ite ==1 
                  
                     FD_MATRIX_OLD = FD_MATRIX_NEW;
        
                     FD_MATRIX_DELTA (1:8,i)= FD_MATRIX_NEW(1:8,i);
        
                     else 
                     
                     FD_MATRIX_DELTA (1:8,i)= (FD_MATRIX_NEW(1:8,i) - FD_MATRIX_OLD(1:8,i));
                   
                     %FD_MATRIX_DELTA (1:8,i)= (FD_MATRIX_OLD(1:8,i))-(FD_MATRIX_NEW(1:8,i));
        
                     end
              
                     delta_Fd (1:8,1) = FD_MATRIX_DELTA(1:8,i);
                      
       
     elseif  Xb(i,1)==1  
         
     [Fpressure_e]=DELTA_Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A);    
     FD_MATRIX_NEW (1:8,i)= Fpressure_e';    
         
             delta_Fd (1:8,1) =  FD_MATRIX_NEW(1:8,i);
       
       else       
           
       % Npress = [0,0,0,0,0,0,0,0;
       %     0,0,0,0,0,-1,0,-1];  
        
        Npress = [0,0,0,0,0,0,0,0;
            0,0,0,0,0,0,0,0]; 
        
        Fpressure_e = (1/2)*[Po*A,Po*A]*Npress;   
         
         
        delta_Fd = Fpressure_e'; 
        
        FD_MATRIX_NEW (1:8,i)= Fpressure_e';
                    
       end 
       
       
% Sensibilidade  completa 

%alpha_e_completo(i,1) =  (((D_SIGMAG_PN_SIGMA_VM(i,1))*((D_SIGMA_VM(1:3,i))')*(p*(Xnew(i))^(p-1))*D*B*Ue)+(LAMBDA_elem*((p*(Xnew(i))^(p-1))*Ke*Ue)));
alpha_e_completo(i,1) =  (((D_SIGMAG_PN_SIGMA_VM(i,1))*((D_SIGMA_VM(1:3,i))')*(p*(Xnew(i))^(p-1))*D*B*Ue)-(LAMBDA_elem*((p*(Xnew(i))^(p-1))*Ke*Ue)));

alpha_e_completo(i,1) = - alpha_e_completo(i,1);
       
% %% Sensibilidade Huang so Stress com carga dependente 

 alpha_e(i,1) = -(LAMBDA_elem*(((1+p)/(((1+p*(1-(Xnew(i))))^2)))*(Ke)*(Ue)))*(Xnew(i));%+(LAMBDA_elem*((V_elem *rho*g/(p+1)))*Ft');
 
 alpha_e(i,1) = - alpha_e(i,1);
 
 % 

 alpha_e_simp(i,1) = -(LAMBDA_elem*((1/(((1+p*(1-(Xnew(i))))^2)))*(Ke)*(Ue)))*(Xnew(i))+(LAMBDA_elem*delta_Fd /(p+1));%+(LAMBDA_elem*((V_elem *rho*g/(p+1)))*Ft');
 
 alpha_e_simp(i,1) = - alpha_e_simp(i,1);
%  
%% Xie so compliance com carga dependente  

%slope Compliance%

% alpha_e(i,1) =  ((1/(2*((1+p*(1-x))^2)))*(Ue')*(Ke)*(Ue))*(Xnew(i));

%alpha_e_simp(i,1) = ((1/(2*((1+p*(1-x))^2)))*(Ue')*(Ke)*(Ue))*(Xnew(i))-(delta_Fd'*Ue) - (((V_elem *rho*g)/(p+1))*Ft*Ue); 

 
 %% Xie Stress e compliance com carga dependente
 
%  alpha_e_simp(i,1) = ((Xnew(i))*NORMA_P^(1-Pn_factor)*LAMBDA_elem*Ke*Ue) + ((((Xnew(i))^(q-1))/2)*Ue'*(Ke)* Ue)+(LAMBDA_elem*Fd'); 
 
% alpha_e_simp(i,1) = ((Xnew(i))*NORMA_P^(1-Pn_factor)*LAMBDA_elem*Ke*Ue) + ((((Xnew(i))^(q-1))/2)*Ue'*(Ke)* Ue)+(LAMBDA_elem*Fd')+ (Fd*Ue); 
  
 %%
 parcela_compliance = ((((Xnew(i))^(q-1))/2)*Ue'*(Ke)* Ue);
 
%parcela_tensoes = -(LAMBDA_elem*((p*(Xnew(i))^(p-1))*Ke*Ue));
 
 parcela_tensoes = ((Xnew(i))*NORMA_P^(1-Pn_factor)*LAMBDA_elem*Ke*Ue);
 
 %parcela_cargadependente = (LAMBDA_elem*delta_Fd');


%% FUNCAO

Y(i,1) = NORMA_P;

Y_UKU = 0.5*UKU;

end

% %% Plot parcelas
% 
%   X=1:nel;
%   figure('Name','Parcelas Sensibilidade','NumberTitle','off');
%   plot(X,Parcela1,'g',X,Parcela1,'o');
%   legend('Parcela1', 'Parcela2')
%   grid on 

%% DERIVADA

dY = -alpha_e;

dY_UKU = -alpha_e;

end


