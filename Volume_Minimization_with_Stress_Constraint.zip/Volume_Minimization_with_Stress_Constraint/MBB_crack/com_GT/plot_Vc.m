function  plot_Vc(Vc,ite,V)



figure('Name','Vc and Volume fraction ','NumberTitle','off');
%figure('Name','','NumberTitle','off');

%[AX,H1,H2]=plotyy(1:ite,Vc,1:ite,V(2:end)*100);
%[V(ite+1);Vc(ite)]
[AX,H1,H2]=plotyy(1:ite,Vc(1:end-1),1:ite,V(2:end));

set(AX,{'ycolor'},{'k';'k'}); legend('\it V^c','\it V_{k+1}')
set(get(AX(1),'Ylabel'),'String','Volume fraction (\it V / V_i )');
%set(get(AX(2),'Ylabel'),'String','Volume fraction ( \it V / V_i )');

set(AX(1),'YLim',[0.9*min(Vc) 1.0*max(Vc)])
set(AX(1),'YLim',[0.9*min(Vc) 1.0*max(Vc)]); set(AX(2),'YTick',0:10:100);
%set(AX(1),'YTick',linspace(0.9*min(Vc),1.05*max(Vc),11))
%set(AX(2),'YLim',[0 100]); set(AX(2),'YTick',0:10:100);
set(AX(2),'YLim',[0.9*min(Vc) 1.0*max(Vc)]); set(AX(2),'YTick',0:10:100);

%xlabel('Iteration'); title('\fontsize{13}P-norm Stress and Volume fraction')
set(H1,'LineStyle','-','Marker','*');set(H2,'LineStyle','-','Marker','d');

grid on

tiy = get(gca,'ytick')';
set(gca,'yticklabel',num2str(tiy,'%.2f'))
ft = 'Times';

fsz = 16;       

set(findall(gcf,'type','text'), 'FontSize', fsz, 'Color', 'k','FontName', ft)
set(gca,'FontSize', fsz, 'FontName', ft)

end