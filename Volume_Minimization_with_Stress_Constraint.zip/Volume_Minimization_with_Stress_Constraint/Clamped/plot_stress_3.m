function plot_stress_3(coord,inci,Xnew,alphaS,fixednodes)
%----------------------------------------------------------------------
%   ## PLOTAGEM DA EVOLU��O ESTRUTURAL ##
%----------------------------------------------------------------------
figure('Name','vm Stress','NumberTitle','off'); 

clf % limpa a figura

Xnew_modified = Xnew;

% elem_restriction = 1;
% 
% for j=2:size(fixednodes,2)
% 
% elem_restr_i = find(inci(:,1)== fixednodes(j));
% elem_restriction = [elem_restriction;elem_restr_i];
% 
% end
% 
% Xnew_modified(elem_restriction)= 0;

ListSolid= find(Xnew_modified==1);

cor = alphaS(ListSolid);

f = inci(ListSolid,3:end);
v = coord(:,2:end);

colormap(gray)
colormap(jet)
patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');

axis off 
axis equal
%pause(0.001)  

ft = 'Times';
fsz = 16;       

set(findall(gcf,'type','text'), 'FontSize', fsz, 'Color', 'k','FontName', ft)
set(gca,'FontSize', fsz, 'FontName', ft)

pause(0.01) 
end