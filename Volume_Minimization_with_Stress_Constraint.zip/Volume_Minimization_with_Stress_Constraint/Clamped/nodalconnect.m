% Function for nodal connectivity matrix generation

function [noconnect] = nodalconnect(nnos,inci)

% Initializing matrix
noconnect = zeros(nnos,5); % no QUAD 4, no m�ximo 4 elementos estar�o associados aquele n� 

for j = 1:nnos
    
    % Elements connected to the node j (encontra os elementos conectados ao n� j)
    connectel = [find(inci(:,2) == j); find(inci(:,3) == j);
                 find(inci(:,4) == j); find(inci(:,5) == j)];
    
    % Sorting conectel
    connectel = sort(connectel);
            
    % Allocating conectel
    noconnect(j,1) = j;                     
    noconnect(j,(2:length(connectel)+1)) = connectel;
end

end