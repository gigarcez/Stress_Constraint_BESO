function  plot_Max_VM_stress_2 (Stress_max_ITE,ite,sigma_restr)

 sigma_restr_vector (1:ite) = sigma_restr./1e6;
 Stress_max_ITE = Stress_max_ITE./1e6;
 
figure('Name','Max. VM Stress and Stress constraint','NumberTitle','off');


[AX,H1,H2]=plotyy(1:ite,Stress_max_ITE(1:end),1:ite,sigma_restr_vector(1:end));
%[AX,H1,H2]=plotyy(1:ite-1,Stress_max_ITE(1:end),1:ite-1,sigma_restr_vector(1:end-1));


set(AX,{'ycolor'},{'k';'k'}); legend('Max. VM Stress','Yield strength')
set(get(AX(1),'Ylabel'),'String','Max. VM Stress (MPa)');
%set(get(AX(2),'Ylabel'),'String','Yield strength (MPa)');

set(AX(1),'YLim',[0.95*min(Stress_max_ITE) 1.05*max(Stress_max_ITE)])
set(AX(1),'YTick',linspace(0.95*min(Stress_max_ITE),1.05*max(Stress_max_ITE),11))

set(AX(2),'YLim',[0.95*min(Stress_max_ITE) 1.05*max(Stress_max_ITE)])
%set(AX(2),'YTick',linspace(0.95*min(Stress_max_ITE),1.05*max(Stress_max_ITE),11))
 set(AX(2),'YLim',[0.95*min(Stress_max_ITE) 1.05*max(Stress_max_ITE)]); set(AX(2),'YTick',0:10:100);


%set(AX(2),'YLim',[0 100]); set(AX(2),'YTick',0:10:100);

%xlabel('Iteration'); title('\fontsize{13}P-norm Stress and Volume fraction')
set(H1,'LineStyle','-','Marker','*');set(H2,'LineStyle','-');

grid on

 tiy = get(gca,'ytick')';
 set(gca,'yticklabel',num2str(tiy,'%.0f'))

end