% Numerical filter for sensitivity numbers in BEFSO analysis

function [alphaS] = filterBEFSOH(nel,nnos,noconnect,designD,designD_no,fixedsolid,alpha,H)

% Initializing vectors
alphaS = zeros(nel,1); % alpha por elemento 
alphanodal = zeros(nnos,1); % alpha por n�

% Loop for nodal sensitivity evaluation
for j = 1:length(designD_no)
    
    % Node
    noD = designD_no(j);
    
    % Nodal alpha
    alphanodal(noD) = mean(alpha(nonzeros(noconnect(noD,2:5))));
    
end

% Filtering matrix application
alphaS(designD) = H*alphanodal(designD_no);

%-------------------------------------------------------------------------%
%Defining elements that can not change their state

% Maximum value of alphaS
vmax = max(abs(alphaS));

% Alpha for fixed fluid elements
alphaS(setdiff([1:nel]',designD)) = vmax*(-1000);

if (length(fixedsolid) > 1)
    % Alpha for fixed solid elements
    alphaS(fixedsolid) = vmax*(1000);
end

end