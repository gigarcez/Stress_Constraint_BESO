function[Xnew] = updatematBESO_dependent(ARi,ARi_loaded,ARmax,In,In_loaded,mat,designD,N_designD,nath,ite,V,x_min)
                                   
                
mat(find(mat==x_min)) = 0;
  
% Removing/adding elements

  mat(In_loaded(1:nath)) = 1;
  mat(In((nath+1):end)) = 0;
        


% Updating type of elements
% inci(:,1) = mat;


Xnew = mat;
Xnew(find(Xnew==0))= x_min;
%Xnew(N_designD)= x_min;

end