function [Ke,Fpp_e] = elem_elast_quad(g,i,lz,coord,conectivity,mat_prop)

conect    = conectivity(i,:);
Pos_xy = coord(conect(2:length(conect)),2:3);

% Propriedades do material
E  = mat_prop(1,1);
nu = mat_prop(1,2);
rho = mat_prop(1,3);

D = [-E/(-1+nu^2),   -nu*E/(-1+nu^2), 0
    -nu*E/(-1+nu^2), -E/(-1+nu^2),    0
    0,                0,              E/(2*(1+nu))];

np=2;% Numero de pontos na Integra�ao de Gauss

[pg wg] = IntGauss(np);

N_fun = length(conect)-1;
Ke = zeros(2*N_fun);
B = zeros(3,2*N_fun);
Fpp_e = zeros(8,1);

for i=1:np
    ksi=pg(i);
    for j=1:np
        eta=pg(j);
        
        % Fun��es de Forma Nq
         Nq(1) = 1/4-1/4*ksi-1/4*eta+1/4*ksi*eta;
         Nq(2) = 1/4+1/4*ksi-1/4*eta-1/4*ksi*eta;
         Nq(3) = 1/4+1/4*ksi+1/4*eta+1/4*ksi*eta;
         Nq(4) = 1/4-1/4*ksi+1/4*eta-1/4*ksi*eta;
        
        % Derivada das fun��es de forma com rela��o a ksi
        
        dNqk(1) = -1/4+1/4*eta;
        dNqk(2) = 1/4-1/4*eta;
        dNqk(3) = 1/4+1/4*eta;
        dNqk(4) = -1/4-1/4*eta;
        
         % Matriz utilizada para calculo de cargas distribu�das ou carga dependente
         
         
         Nf = [Nq(1),0,Nq(2),0,Nq(3),0,Nq(4),0;
              0,Nq(1),0,Nq(2),0,Nq(3),0,Nq(4)];
                 
        
        % Derivada das fun��es de forma com rela��o a eta
        
        dNqe(1) = -1/4+1/4*ksi;
        dNqe(2) = -1/4-1/4*ksi;
        dNqe(3) = 1/4+1/4*ksi;
        dNqe(4) = 1/4-1/4*ksi;
        
        % Determina��o do Jacobiano
        J  = [dNqk;dNqe]*Pos_xy;
        iJ = J^-1;
        
        % Determina��o da Matriz de Deforma�ao B
        p = 1:2:2*N_fun;
        B(1,p)   = iJ(1,1)*dNqk + iJ(1,2)*dNqe;
        B(2,p+1) = iJ(2,1)*dNqk + iJ(2,2)*dNqe;
        B(3,p)   = B(2,p+1);
        B(3,p+1) = B(1,p);
        
        Ke = Ke + B'*D*B*lz*det(J)*wg(i)*wg(j);
        
        % Peso Pr�prio
        
        Fpp_elem = - [0;rho*g]; 
        Fpp_e = Fpp_e + Nf'*Fpp_elem *lz*det(J)*wg(i)*wg(j);
        
    end
end


