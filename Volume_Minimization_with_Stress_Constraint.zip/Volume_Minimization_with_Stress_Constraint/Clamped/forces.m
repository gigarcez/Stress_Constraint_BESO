function [Fg]=forces(Forcas,coord)

nnos=size(coord,1); %numero de n�s
Fg = zeros(2*nnos,1);
id= reshape(1:2*nnos,2,nnos);

for i=1:size(Forcas,1) %numero de for�as externas (numero de linhas da Matriz de Carga)
        Fg(id(Forcas(i,2),Forcas(i,1)),1)= Forcas(i,3);
end