
function plotstress_final(coord,inci,elem_list,VM_stress,N_designD)

figure('Name','vm Stress','NumberTitle','off'); 

%VM_stress(N_designD)= 0;

clf % limpa a figura
%ListSolid= find(Xnew==1);
Listelem= elem_list;
cor = VM_stress(Listelem);

f = inci(Listelem,3:end);
v = coord(:,2:end);

colormap(gray)
colormap(jet)
patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');

axis off 
axis equal
%pause(0.001)  
pause(0.01) 
end