function ANSYS_OUTPUT(coord,inci,Forcas,fixednodes)
%%  COORD ANSYS OUTPUT COORD

 disp( ' '),disp( 'coord Ansys'); disp( ' ')

for i=1:size(coord(:,1))
       
    coord_1=coord(i,1);
    coord_2=coord(i,2);
    coord_3=coord(i,3);

disp(['N,' sprintf('%4.0f',coord_1)   ', ' sprintf('%7.4f',coord_2) ', ' sprintf('%7.4f',coord_3) ])

end 
%% INCIDENCE ANSYS OUTPUT

 disp( ' '),disp( 'incidence Ansys'); disp( ' ')
 
 
 for j=1:size(inci(:,1))
     
     node_1 = inci(j,3);
     node_2 = inci(j,4);
     node_3 = inci(j,5);
     node_4 = inci(j,6);

disp(['e,' sprintf('%4.0f',node_1)   ', ' sprintf('%5.0f',node_2) ', ' sprintf('%5.0f',node_3) ', ' sprintf('%5.0f',node_4) ])

 end 


%% FORCE ANSYS OUTPUT

disp( ' '),disp( 'forces Ansys'); disp( ' ')

for k=1:size(Forcas,1)
    
    nodef =  Forcas(k,1);
    direcaof = Forcas(k,2);
    valor = Forcas(k,3);
    
    if direcaof==1
    
   disp(['F,' sprintf('%4.0f',nodef) ','  'FX,'    sprintf('%4.0f',valor)])
   
    elseif direcaof==2
        
    disp(['F,' sprintf('%4.0f',nodef) ','  'FY,'    sprintf('%4.0f',valor)]) 
    
    end

end

%% BOUNDARY CONDITIONS ANSYS OUTPUT

disp( ' '),disp( 'BC Ansys'); disp( ' ')
fix = fixednodes';

for l=1:size(fix,1)
    
    %D,1,UX, 0
    
    fixes = fix(l,1);
    
   disp(['D,' sprintf('%4.0f',fixes) ','  'UX,'    '0'])   
   disp(['D,' sprintf('%4.0f',fixes) ','  'UY,'    '0']) 
   
end
%%

disp( ' ')

end
