function [Y1,Y1_UKU_DF,UKU_DF] = sensibility_DF_min_stress(coord,inci,Xnew,mat_prop,Ke,Fg,x_min,freedofs,fixeddofs,delta,D,B,Pn_factor,LAMBDA,p);
%function [alpha_e_DF,Y1,dY1,Y1_UKU_DF,dY1_UKU_DF,UKU_DF] = sensibility_DF_min_stress(coord,inci,Xnew,mat_prop,Ke,Fg,x_min,freedofs,fixeddofs,delta,D,B,Pn_factor,LAMBDA,p);

nnos = size(coord,1); 
nel = length(inci(:,1)); 
id = reshape(1:2*nnos,2,nnos);
U_DF = zeros(2*nnos,1);% inicializa��o do vetor deslocamento

Xnew_orign = Xnew;

% p = 1; % na minimiza��o das tens�es o p passa a ser 1 ( de acordo com Huang) 

for i=1:nel
    
NORMA_P_DF = 0;
    
Xnew = Xnew_orign;

Xnew(i,1)= Xnew(i,1)+ delta;

%%Assembly

[Kg_DF] =Kassembly_DF(inci,id,Ke,delta,nel,Xnew,x_min,p);

U_DF(freedofs) = Kg_DF(freedofs,freedofs)\Fg(freedofs); U_DF(fixeddofs)= 0;

[GLOBAL_STRESS_DF,VM_stress_DF] = von_Misses(U_DF,coord,inci,mat_prop,Xnew,p);                                               

[NORMA_P_DF,D_SIGMAG_PN_SIGMA_VM_DF,D_SIGMA_VM_DF] = P_Norm(nel,GLOBAL_STRESS_DF,VM_stress_DF,Pn_factor);


 pos=[id(1,inci(i,3)) id(2,inci(i,3)) id(1,inci(i,4)) id(2,inci(i,4)) id(1,inci(i,5)) id(2,inci(i,5)) id(1,inci(i,6)) id(2,inci(i,6))]; %
 
 Ue_DF = (U_DF(pos));
 
 UKU_DF(i,1) = Ue_DF'*Ke*Ue_DF;
 
% FUNCAO

 Y1(i,1) = NORMA_P_DF;

 Y1_UKU_DF  = 0.5*UKU_DF;  
% 


end


