
function[CORDENADAS_X,all_nodes_x0] = CORDENADASX(coord)

all_nodes_x0 = find(coord(:,3)==0);

for nos=1:size(coord,1)
    for elemx0=1:size(all_nodes_x0,1)
     if coord(nos,1)==all_nodes_x0(elemx0,1)
     coord_X_ZEROS(elemx0,:)=coord((all_nodes_x0(elemx0)),1:3);
     else
     end
    end
end

CORDENADAS_X=coord_X_ZEROS(:,2);