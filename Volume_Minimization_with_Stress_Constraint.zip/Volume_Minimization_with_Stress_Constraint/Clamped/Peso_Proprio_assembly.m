function[Fpp] = Peso_Proprio_assembly(coord,inci,Fpp, Fpp_e,mat_prev,mat,x_min,p);
 
 %Fpp_e_xmin =  Fpp_e*(x_min^p); 
 

nnos = size(coord,1); 
nel = length(inci(:,1)); 
ID = reshape(1:2*nnos,2,nnos);
        
  for i = 1:nel

   if ((mat_prev(i) == 1) && (mat(i) ~=1))  % Solid-Void _ Soft Kill       
       
        no1 = inci(i,3);
        no2 = inci(i,4);
        no3 = inci(i,5);
        no4 = inci(i,6);
        
        
   % Vector with element DOF's
        loc = [ID(1,no1),ID(2,no1),ID(1,no2),ID(2,no2),ID(1,no3),ID(2,no3),ID(1,no4),ID(2,no4)];
           
        Fpp(loc) = Fpp(loc) - (Fpp_e);  
        
   elseif ((mat_prev(i) ~=1) && (mat(i) == 1))   % Void-Solid - Soft Kill  
       
        % Nodes connected to the element i
        no1 = inci(i,3);
        no2 = inci(i,4);
        no3 = inci(i,5);
        no4 = inci(i,6);
        
        % Vector with element DOF's
        loc = [ID(1,no1),ID(2,no1),ID(1,no2),ID(2,no2),ID(1,no3),ID(2,no3),ID(1,no4),ID(2,no4)];
               
      Fpp(loc)  = Fpp(loc) + (Fpp_e) ;     
      
   end  
    
  end

end