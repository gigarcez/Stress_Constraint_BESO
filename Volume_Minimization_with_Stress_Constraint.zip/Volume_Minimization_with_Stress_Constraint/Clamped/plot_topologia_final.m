function plot_topologia_final(coord,inci,Xnew)
%----------------------------------------------------------------------
%   ## PLOTAGEM DA EVOLU��O ESTRUTURAL ##
%----------------------------------------------------------------------
figure(1); 

clf % limpa a figura
ListSolid= find(Xnew==1);
cor = Xnew(ListSolid);
cor(1)=1.00000001;
f = inci(ListSolid,3:end);
v = coord(:,2:end);

colormap(gray)

patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');
%patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');

axis off 
axis equal
%pause(0.001)  
pause(0.01) 
end