function[Norm_erro,erro_max,ERRO_UKU_MAX,ELEMENTO_ERRO_UKU_MAX]=plotfinitedif (coord,inci,Y,dY,Y_UKU,Y1,Y1_UKU_DF,delta)
%function[erro,erro_max]=plotfinitedif (inci,Y,dY,Y1,dY1,delta)

nel = length(inci(:,1));
X=1:nel;

% Diferencial de Euler
df_Euler = (Y1-Y)/(delta);

%df_Euler_UKU = (Y1_UKU_DF-Y_UKU)/(delta);



  figure('Name','Diferencial de Euler','NumberTitle','off');
  plot(X,dY,'g',X,df_Euler,'o');
  legend('Derivada anal�tica', 'Diferencial de Euler')
  grid on
  

 %  Imagem em pdf 
 fig_name = 'validacao delta.pdf';
 print(gcf, '-dpdf', '-r600', fig_name)
  
%dY1_j= repmat(dY1,1,nel)

erro = (abs((dY-df_Euler)*100))./abs(df_Euler);
%erro_UKU = (abs((dY1_UKU_DF-df_Euler_UKU)*100))./abs(df_Euler_UKU);

erro_max= max(erro);
%erro_max_UKU= max(erro_UKU);

% Norma euclidiana do erro
Norm_erro = norm(erro,2);

%% ERRO U K U
ERRO_UKU_ELEM = ((Y1_UKU_DF-Y_UKU)*100)./(Y_UKU);

ERRO_UKU = max(abs(ERRO_UKU_ELEM));

ERRO_UKU_MAX = max(abs(ERRO_UKU_ELEM));

ELEMENTO_ERRO_UKU_MAX=find(ERRO_UKU==ERRO_UKU_MAX);
%% Plot erro UKU

%ploterro_UKU(coord,inci,ERRO_UKU_ELEM,Y_UKU,Y1_UKU_DF)


end
