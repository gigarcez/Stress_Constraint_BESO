function plot_Compliance(SUM_ALPHA,ite,V)

%figure('Name','Sensitivity and Volume fraction ','NumberTitle','off');

figure('Name','Compliance and Volume fraction ','NumberTitle','off');
[AX,H1,H2]=plotyy(1:ite,SUM_ALPHA,1:ite,V(2:end)*100);

%set(AX,{'ycolor'},{'k';'k'}); legend('Sensitivity','Volume fraction')
set(AX,{'ycolor'},{'k';'k'}); legend('Compliance','Volume fraction')
%set(get(AX(1),'Ylabel'),'String','Sensitivity');
set(get(AX(1),'Ylabel'),'String','Compliance');
set(get(AX(2),'Ylabel'),'String','Volume fraction (V/V_i)');

set(AX(1),'YLim',[0.95*min(SUM_ALPHA) 1.25*max(SUM_ALPHA)])
set(AX(1),'YTick',linspace(0.95*min(SUM_ALPHA),1.25*max(SUM_ALPHA),11))
set(AX(2),'YLim',[0 100]); set(AX(2),'YTick',0:10:100);

%xlabel('Iteration'); title('\fontsize{13} Sensitivity and Volume fraction')
xlabel('Iteration'); title('\fontsize{13} Compliance and Volume fraction')

set(H1,'LineStyle','-','Marker','*');set(H2,'LineStyle','-','Marker','d');

grid on


end
