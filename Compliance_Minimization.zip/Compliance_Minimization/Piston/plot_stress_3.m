function plot_stress_3(coord,inci,Xnew,alphaS)
%----------------------------------------------------------------------
%   ## PLOTAGEM DA EVOLU��O ESTRUTURAL ##
%----------------------------------------------------------------------
figure('Name','vm Stress','NumberTitle','off'); 

clf % limpa a figura
ListSolid= find(Xnew==1);
cor = alphaS(ListSolid);

f = inci(ListSolid,3:end);
v = coord(:,2:end);

colormap(gray)
colormap(jet)
patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');

axis off 
axis equal

ft = 'Times';
fsz = 16;       

set(findall(gcf,'type','text'), 'FontSize', fsz, 'Color', 'k','FontName', ft)
set(gca,'FontSize', fsz, 'FontName', ft)

%pause(0.001)  
pause(0.01) 
end