  
function [Fpressure_e]=Press_Vector(VETOR_MALHA,elside,elements_boundary,Po,A)

Nelx = VETOR_MALHA(1,4);
Nely = VETOR_MALHA(1,5);

lx = VETOR_MALHA(1,1);
ly = VETOR_MALHA(1,2);
lz = VETOR_MALHA(1,3);

%F_pressure = VETOR_MALHA(1,7);

elements_boundary=nonzeros(elements_boundary);

limite_superior = size(elements_boundary,1);

  for i_distr=1:limite_superior    
     
  elside_new=(nonzeros(elside(elements_boundary(i_distr,1),2:5)))';

  size_elside=size(elside_new,2); 
 
  el_Face2=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))-1);
  if el_Face2~=0; Face2=0;else Face2=1;end;
 
  el_Face3=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))+1);
  if el_Face3(1,:)~=0;Face3=0;else Face3=-1;end;

  el_Face4=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))+Nelx);
  if el_Face4(1,:)~=0;Face4=0;else Face4=-1;end; 

  if (elements_boundary(i_distr))-Nelx<=0;down=0;else down=(elements_boundary(i_distr))-Nelx;end;
  el_Face1=intersect(elside_new(1,1:size_elside),down);
  if el_Face1(1,:)~=0;Face1=0;else Face1=1;end; 


%Sliding force:  
%if i_distr == 1 || i_distr == limite_superior
% Face2=0;Face3=0; 
% else     
% end

% somente tira o carregamento das laterais
 if i_distr == 1 || i_distr == limite_superior
 Face2=0;Face3=0;       
 else     
 end
 
 Npress = [Face2,Face1,Face3,Face1,Face3,Face4,Face2,Face4];       
        
 Fpressure_e = (1/2)*Po*A*Npress;      
  
     
  end
 end