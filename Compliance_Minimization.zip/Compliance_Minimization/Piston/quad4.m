function [coord,conectivity] = quad4(Lx,Ly,nx,ny)

nnx=nx+1;    % node numbers -  x direction
nny=ny+1;    % node numbers -  y direction

x=0:(Lx/nx):Lx; % Vector with the nodes positions - x
y=0:(Ly/ny):Ly; % Vector with the nodes positions - y

[X,Y]=meshgrid(x,y); % 2D Meshgird 

%% coord matrix
 for i=1:nny
  coord(((i-1)*nnx+1:i*nnx)',:) = [((i-1)*nnx+1:i*nnx)',X(i,:)',Y(i,:)']; 
 end
 
%% incidence matrix
 for i=1:ny
  conectivity(((i-1)*nx+1:i*nx)',:) = [ ((i-1)*nx+1:i*nx)',((i-1)*nnx+1:i*nnx-1)',((i-1)*nnx+2:i*nnx)',(i*nnx+2:(i+1)*nnx)',(i*nnx+1:(i+1)*nnx-1)'];
 end
end
     
 

 


