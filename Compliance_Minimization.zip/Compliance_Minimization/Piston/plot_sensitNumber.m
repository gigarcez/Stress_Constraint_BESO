function plot_sensitNumber(coord,inci,Xnew,alphaS)
clf % limpa a figura
ListSolid= find(Xnew==1);
cor = alphaS(ListSolid);

f = inci(ListSolid,3:end);
v = coord(:,2:end);

colormap(gray)
colormap(jet)
patch('Faces',f,'Vertices',v,'FaceVertexCData',cor,'FaceColor','flat','EdgeColor','none');

axis off 
axis equal
%pause(0.001)  
pause(0.01) 
end