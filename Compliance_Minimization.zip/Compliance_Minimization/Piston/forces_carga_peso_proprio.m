function [Fpp] = forces_carga_distribuida(coord,inci,Fpp_e)

nnos = size(coord,1); 
nel = length(inci(:,1)); 
Fpp = zeros(2*nnos,1);
id = reshape(1:2*nnos,2,nnos);

 for i = 1:nel
       
    NO_1 = inci(i,3);
    NO_2 = inci(i,4);
    NO_3 = inci(i,5);
    NO_4 = inci(i,6);
    
    % Posi��o na Matriz de Rigidez

     pos=[id(1,NO_1) id(2,NO_1) id(1,NO_2) id(2,NO_2) id(1,NO_3) id(2,NO_3) id(1,NO_4) id(2,NO_4)]; %
    
    for lin_Fe = 1:8 %
        lin_FG = pos(lin_Fe);
          if any(lin_FG);
             Fpp(lin_FG) = Fpp(lin_FG)+Fpp_e(lin_Fe);
          end
    end
    
 end

end

