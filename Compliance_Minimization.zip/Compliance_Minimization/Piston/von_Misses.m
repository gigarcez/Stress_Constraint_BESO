function [GLOBAL_STRESS,VM_stress] = von_Misses(U,coord,inci,mat_prop,Xnew,penal)

Nel = size(inci,1);
nnos=size(coord,1); %numero de n�s
id = reshape(1:2*nnos,2,nnos);
VM_stress=zeros(Nel,1);

E0  = mat_prop(1,1);
nu = mat_prop(1,2);

for i_nel = 1:Nel
    
E = zeros(1);
   
cnxy = [coord(inci(i_nel,3),2), coord(inci(i_nel,3),3);
        coord(inci(i_nel,4),2), coord(inci(i_nel,4),3);
        coord(inci(i_nel,5),2), coord(inci(i_nel,5),3);
        coord(inci(i_nel,6),2), coord(inci(i_nel,6),3)];

pos=[id(1,inci(i_nel,3)) id(2,inci(i_nel,3)) id(1,inci(i_nel,4)) id(2,inci(i_nel,4)) id(1,inci(i_nel,5)) id(2,inci(i_nel,5)) id(1,inci(i_nel,6)) id(2,inci(i_nel,6))]; %

%% Propriedades do material

%E  = E0*((Xnew(i_nel))^(penal));
E  = E0*((Xnew(i_nel))/(1+(penal)*(1-(Xnew(i_nel)))));

D = [-E/(-1+nu^2),   -nu*E/(-1+nu^2), 0
    -nu*E/(-1+nu^2), -E/(-1+nu^2),    0
    0,                0,              E/(2*(1+nu))];

np=2;% Numero de pontos na Integra�ao de Gauss
[pg wg] = IntGauss(np);

%% tens�es no centroide dos elementos

    ksi = 0; % centr�ide do elemento
    eta = 0; % centr�ide do elemento   
    
    N_fun = 4;
    B = zeros(3,2*N_fun);
        
        % Fun��es de Forma Nq
%         Nq(1) = 1/4-1/4*ksi-1/4*eta+1/4*ksi*eta;
%         Nq(2) = 1/4+1/4*ksi-1/4*eta-1/4*ksi*eta;
%         Nq(3) = 1/4+1/4*ksi+1/4*eta+1/4*ksi*eta;
%         Nq(4) = 1/4-1/4*ksi+1/4*eta-1/4*ksi*eta;
        
        % Derivada das fun��es de forma com rela��o a ksi
        dNqk(1) = -1/4+1/4*eta;
        dNqk(2) = 1/4-1/4*eta;
        dNqk(3) = 1/4+1/4*eta;
        dNqk(4) = -1/4-1/4*eta;
        
        % Derivada das fun��es de forma com rela��o a eta
        dNqe(1) = -1/4+1/4*ksi;
        dNqe(2) = -1/4-1/4*ksi;
        dNqe(3) = 1/4+1/4*ksi;
        dNqe(4) = 1/4-1/4*ksi;
        
        % Determina��o do Jacobiano
        J  = [dNqk;dNqe]*cnxy;
        iJ = J^-1;
        
        % Determina��o da Matriz de Deforma�ao B
        p = 1:2:2*N_fun;
        B(1,p)   = iJ(1,1)*dNqk + iJ(1,2)*dNqe;
        B(2,p+1) = iJ(2,1)*dNqk + iJ(2,2)*dNqe;
        B(3,p)   = B(2,p+1);
        B(3,p+1) = B(1,p);        
        
        [Ue] = U(pos);  
  
        % tens�o no elemento  
        
        sigma = D*B*Ue;   %tens�es st: sigma_x/sigma_y/tau_xy
        
        GLOBAL_STRESS(1:3,i_nel) = sigma;

        % von Mises Stress 
        
        VM_stress(i_nel)=  sqrt((((sigma(1)-sigma(2))^2) +((sigma(1))^2)+((sigma(2))^2) +(6*((sigma(3))^2)))/2); 
             

end


end
