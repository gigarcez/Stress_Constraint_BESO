function [Fpress,elements_boundary,Xb,side,elside,crust,crust_all] = forces_carga_uniformemente_distribuida(CORDENADAS_X,all_nodes_x0,coord,inci,Conectivity,Xnew,x_min,VETOR_MALHA,noconnect,Local_Carga,Po,A);

nel = length(inci(:,1)); 
nnos = size(coord,1); 
%Conectivity = [inci(:,1), inci(:,3:6)];

%% Assembly da carga uniformemente distribuida 

elements_Xnew=find(Xnew==1);size_elements_new=size(elements_Xnew,1);

Conectivity_new= Conectivity(elements_Xnew,1:5);

nodes_Xnew = nonzeros(unique(Conectivity(elements_Xnew,2:5)));COORD_new=coord(nodes_Xnew,1:3);

%% Elementos Vizinhos

%[noconnect] = nodalconnect(nnos,Conectivity); % Matriz Conectividade Nodal
[side,elside] = elvizinho(nel,Conectivity,noconnect,Xnew); 

%% Pressao

%crust=unique([find(side(:,2)==1);find(side(:,2)==2);find(side(:,2)==3)]);

%% Carga Uniformemente Distribuida


% seleciona quem n�o tem 4 elementos vizinhos de lado:
crust_all=unique([find(side(:,2)==1);find(side(:,2)==2);find(side(:,2)==3)]);
%crust_all=unique([find(side(:,2)==1);find(side(:,2)==2);find(side(:,2)==3);find(side(:,3)==1);find(side(:,3)==2);find(side(:,3)==3)]);

crust=intersect(elements_Xnew,crust_all);

%   figure(11); clf % limpa a figura
%   
%   patch('Faces',inci(Xnew>0.5,3:6),'Vertices',coord(:,2:3),'FaceColor','m')
%   hold on
%   patch('Faces',inci(crust,3:6),'Vertices',coord(:,2:3),'FaceColor','b')

[elements_boundary,Fpress]= BOUNDARY_CARGA_UNF_DISTR(CORDENADAS_X,all_nodes_x0,VETOR_MALHA,inci,coord,Conectivity,crust,elside,Local_Carga,Po,A);


 %% Atualiza��o do vetor bin�rio que determina se o elemento pertence a borda
 
 Xb = ones(nel,1); 
 
 for i_b=1:nel
 
     teste = intersect(i_b,elements_boundary);
     
     if teste ~= 0
     
     Xb(i_b,1) = 1;
     
     else 
    Xb(i_b,1) = x_min;
     end
  
 end

end