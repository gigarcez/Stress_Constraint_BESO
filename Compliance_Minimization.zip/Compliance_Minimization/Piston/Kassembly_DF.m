% Function for K global matrix assembly 

function [Kg_DF] = Kassembly_DF(inci,id,Ke,delta,nel,Xnew,x_min,p);

% Solid elements DOF's
  
   position = [id(1,inci(1:nel,3));
               id(2,inci(1:nel,3));
               id(1,inci(1:nel,4));
               id(2,inci(1:nel,4));
               id(1,inci(1:nel,5));
               id(2,inci(1:nel,5));
               id(1,inci(1:nel,6));
               id(2,inci(1:nel,6))];

% Index vectors

I = reshape(repmat(position,8,1),nel*64,1);
J = kron(position(:),ones(8,1));

 Ke_xmin = Ke*(x_min^p);
 Ke_xmin_delta =  Ke*((x_min+delta)^p);
 Ke_delta = Ke*((1+delta)^p);

 solid = 1+delta;void = x_min+delta;

Kg_DF = kron(Xnew==1,ones(64,1)).*repmat(Ke(:),nel,1)+ kron(Xnew==x_min,ones(64,1)).*repmat(Ke_xmin(:),nel,1) + kron(Xnew==solid,ones(64,1)).*repmat(Ke_delta(:),nel,1)+ kron(Xnew==void,ones(64,1)).*repmat(Ke_xmin_delta(:),nel,1);

% Assembly
Kg_DF = sparse(I,J,Kg_DF);

end