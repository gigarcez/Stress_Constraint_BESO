
function ploterro_UKU(coord,inci,ERRO_UKU_ELEM,Y_UKU,Y1_UKU_DF)

%% plote valores

nel=length(inci(:,1));  %numero de elementos
nnel=size(inci(:,3:end),2);      %Numero de nos por elemento
dimension=size(coord(:,2:end),2); %Dimensao da malha

%Initializacao das matrices
X = zeros(nnel,nel) ;
Y = zeros(nnel,nel) ;

if dimension==2            %For 2D plots
    for iel=1:nel
        for i=1:nnel
            X(i,iel)=coord(inci(iel,i+2),2);
            Y(i,iel)=coord(inci(iel,i+2),3);
        end
    end
    %Plotting the FEM mesh, display Node numbers and erro UKU 
        figure('Name','Erro UKU ','NumberTitle','off');
        plot(X,Y,'k') 
        title('ERRO UKU') 
        fill(X,Y,'w') % Preenche os elementos de branco para ficar mais visivel
        axis off 
        axis equal
    %Numeracao

    text(coord(:,2),coord(:,3),int2str(coord(:,1)),'fontsize',8,'color','k');       
    er = num2str(single(ERRO_UKU_ELEM(i))); 
       for i = 1:nel  
            text(sum(X(:,i))/4.5,sum(Y(:,i))/4,er,'fontsize',10,'color','b');   
       end

end

%%   PLOTAGEM Do ERRO UKU

    figure('Name','PLOT Erro UKU CORES','NumberTitle','off');  
    patch('Faces',inci(:,3:6),'Vertices',coord(:,2:3),'FaceVertexCData',ERRO_UKU_ELEM,'FaceColor','flat');
    colormap('jet');
    lighting gouraud 
    colorbar
  
    
    %%   PLOTAGEM d UKU

    figure('Name','PLOT UKU','NumberTitle','off');  
    patch('Faces',inci(:,3:6),'Vertices',coord(:,2:3),'FaceVertexCData',Y_UKU,'FaceColor','flat');
    colormap('jet');
    lighting gouraud 
    colorbar
  
        %%   PLOTAGEM d UKU

    figure('Name','PLOT UKU DELTA','NumberTitle','off');  
    patch('Faces',inci(:,3:6),'Vertices',coord(:,2:3),'FaceVertexCData',Y1_UKU_DF,'FaceColor','flat');
    colormap('jet');
    lighting gouraud 
    colorbar
  
end
    



