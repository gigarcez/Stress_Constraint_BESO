function [] = plot_carga_distr(inci,coord,Xnew,elements_boundary,VETOR_MALHA)

lx = VETOR_MALHA(1,1);
ly = VETOR_MALHA(1,2);

figure(11); clf % limpa a figura

patch('Faces',inci(Xnew>0.5,3:6),'Vertices',coord(:,2:3),'FaceColor','m')
hold on
patch('Faces',inci(elements_boundary,3:6),'Vertices',coord(:,2:3),'FaceColor','b')

% axis([-0.10*lx lx*1.10 -ly*0.10 ly*1.10])
% axis equal

axis equal; axis tight; axis off;


hold off

end