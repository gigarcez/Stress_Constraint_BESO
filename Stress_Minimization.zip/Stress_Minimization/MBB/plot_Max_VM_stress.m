function  plot_Max_VM_stress (Stress_max_ITE,ite,sigma_restr)

 sigma_restr_vector (1:ite) = sigma_restr./10e6;
 Stress_max_ITE = Stress_max_ITE./10e6;

figure('Name','Max. VM Stress and Stress constraint','NumberTitle','off');

X = 2:ite;
Y1 = Stress_max_ITE(2:end); 
Y2 = sigma_restr_vector(2:end);


plot(X,Y1,'b--*',X,Y2,'r-');
%plot(x,y1,'g',x,y2,'b--o',x,y3,'c*')


yyaxis left
plot(X,Y1,'k--*');
xlabel('Iteration')
ylabel('Max. VM Stress (MPa)') 

grid on
  tiy = get(gca,'ytick')';
  set(gca,'yticklabel',num2str(tiy,'%.2f'))

yyaxis right
plot(X,Y2,'b-');
xlabel('Iteration')
ylabel(' Stress constraint (MPa)') 

grid on
  tiy = get(gca,'ytick')';
  set(gca,'yticklabel',num2str(tiy,'%.2f'))
  
legend('Max. VM Stress','Stress constraint')
 
end