
function [Forcas,alldofs,fixeddofs,freedofs,fixednodes]= BOUNDARY_CONDITIONS(caso,coord,Lx,Ly,nx,ny,F)

nnos = length(coord(:,1));
alldofs=1:2*nnos;

switch(caso)
    
    case 1 %  simply supported (viga bi-apoiada, carga concendrada no meio)
  
    fixednodes = [1 2 3 4 5 nx+1 nx nx-1 nx-2 nx-3];% apoiada em cinco nos
    fixeddofs = sort([(1)*2-1 (1)*2 (2)*2 (3)*2 (4)*2 (5)*2 (nx+1)*2 (nx)*2 (nx-1)*2 (nx-2)*2 (nx-3)*2]);

    %    fixednodes = [1 nx+1]; % apoiada
%    %fixeddofs=sort([(fixednodes)*2-1   (fixednodes)*2]); %engastada
%    fixeddofs=sort([(1)*2-1   (1)*2   (nx+1)*2]); % apoiada
   
   freedofs=setdiff(alldofs,fixeddofs);

%    Fnode = find(coord(:,2)==Lx/2 & coord(:,3)==Ly); % find central node
%    Forcas = [Fnode,2,F]; 

   Fnode1 = find(coord(:,2)== (floor(Lx*10/3))/10 & coord(:,3)==Ly); % find central node
   Fnode2 = find(coord(:,2)== Lx - ((floor(Lx*10/3))/10) & coord(:,3)==Ly); % find central node
   
   Forcas = [Fnode1,2,F/2;Fnode2,2,F/2]; 
 
    case 2 %  cantilever (viga engastada-livre, carga concendrada na extremidade) 
        
   fixednodes = (find(coord(:,2)==0))'; 
   fixeddofs = sort([(fixednodes)*2-1 (fixednodes)*2]);
   freedofs=setdiff(alldofs,fixeddofs);
   
   Fnode = find(coord(:,2)==Lx & coord(:,3)==Ly/2);    
   Forcas = [Fnode,2,F]; 
    
end


