function[Xnew] = updatematBESO_dependent(ARi,ARi_loaded,ARmax,In,In_loaded,mat,designD,N_designD,nath,ite,V,x_min)
                                   
                 
mat(find(mat==x_min)) = 0;
  
% Removing/adding elements
if (ARi <= ARmax)    % If AR is lesser or equal maximum AR
    
    % Removing/adding elements in Xnew vector
    mat(In_loaded(1:nath)) = 1;
    mat(In((nath+1):end)) = 0;
        
else                  % If AR is greater than maximum AR
        
    % material vector sorted according to In
    In_mat = mat(In);
    In_mat_loaded = mat(In_loaded);
    
       
    % Numbers of elements to be added
    nadd_ath = round(ARmax*length(designD));
    % Adjusting nath for even amount of removed elements
    nadd_ath = round(nadd_ath/4)*4;
        
    % Searching i index in In_mat corresponding to ath_add
    % Counting amount of 2's in In_mat until the value of nadd_nath
    aux_In_mat = 0;
    for i = 1:length(In_mat_loaded)
        if In_mat_loaded(i) == 0
            aux_In_mat = aux_In_mat+1;
            if aux_In_mat == (nadd_ath)
                In_add = i;
                break
            end
        end
    end
        
    % Number of elements to be removed
    nret_ath_aux = round((V(ite+1)-V(ite))*length(designD));
    
    % Adjusting nath for even amount of removed elements
    nret_ath_aux = round(nret_ath_aux/4)*4;
    nret_ath = nadd_ath-nret_ath_aux;
    
    % Searching i index in In_mat corresponding to ath_del
    % Counting amount of 1's in In_mat until the value of nret_nath
    aux_In_mat = 0;
    for i = length(In_mat):(-1):1
        if In_mat(i) == 1
            aux_In_mat = aux_In_mat+1;
            if aux_In_mat == nret_ath
                In_ret = i;
                break
            end
        end
    end
        
    % Removing/adding elements in mat vector
    mat(In_loaded(1:In_add)) = 1;
    mat(In(In_ret:end)) = 0;
      
end

% Updating type of elements
% inci(:,1) = mat;


Xnew = mat;
Xnew(find(Xnew==0))= x_min;
%Xnew(N_designD)= x_min;

end