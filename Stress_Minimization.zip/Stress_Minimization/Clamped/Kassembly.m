% Function for K global matrix assembly 

function [Kg] = Kassembly(coord,inci,Ke,Xnew,x_min,p);

nnos = size(coord,1); 
nel = length(inci(:,1)); 
id = reshape(1:2*nnos,2,nnos);

% Solid elements DOF's
  
   position = [id(1,inci(1:nel,3));
               id(2,inci(1:nel,3));
               id(1,inci(1:nel,4));
               id(2,inci(1:nel,4));
               id(1,inci(1:nel,5));
               id(2,inci(1:nel,5));
               id(1,inci(1:nel,6));
               id(2,inci(1:nel,6))];

% Index vectors

I = reshape(repmat(position,8,1),nel*64,1);
J = kron(position(:),ones(8,1));


%Ke_xmin = Ke*(x_min^p);
Ke_xmin = Ke*(x_min/(1+p*(1-x_min))); % interpola��o de materia para peso pr�prio

%Kg = kron(Xnew==1,ones(64,1)).*repmat(Ke(:),nel,1)+ kron(Xnew==0,ones(64,1)).*repmat(Ke_xmin(:),nel,1);
Kg = kron(Xnew==1,ones(64,1)).*repmat(Ke(:),nel,1)+ kron(Xnew==x_min,ones(64,1)).*repmat(Ke_xmin(:),nel,1);

% Assembly
Kg = sparse(I,J,Kg);

end