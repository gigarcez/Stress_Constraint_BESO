
function [mat_prop,mat,inci] = mat_properties(conectivity,E,ni,rho)

mat_prop = [E,ni,rho];

mat= ones(size(conectivity,1),1); % Todos os elementos tem o mesmo material
inci = [conectivity(:,1),mat(:),conectivity(:,2:end)];

end