function [Xnew,crack_notch3] = stress_filtering(coord,inci,nel,VETOR_MALHA,x_min,Xnew,VM_stress,crust_all,crust_inicial);

Lx = VETOR_MALHA(1,1);
Ly = VETOR_MALHA(1,2);

Nelx = VETOR_MALHA(1,4);

%% Filtro entalhe

VM_stress_min = 1.2*(mean(nonzeros(VM_stress)));

smooth = 0;

 for i= 1:nel  
     
       if VM_stress(i) < VM_stress_min  
         smooth = [smooth;i];
       else
       end
 end  
 
 smooth= unique(nonzeros(smooth));
   
   Fnode1 = find(coord(:,2)== (floor(Lx*10/3))/10 & coord(:,3)==0); % find central node
   Fnode2 = find(coord(:,2)== Lx - ((floor(Lx*10/3))/10) & coord(:,3)==0); % find central node
 
    elemlod_1 = find(inci(:,3) == Fnode1);
    elemlod_2 = find(inci(:,4) == Fnode2);   
    crack_notch_1 = [elemlod_1: elemlod_2]; 
    crack_notch = crack_notch_1;
    for j = 1:9
    crack_notch = [crack_notch,crack_notch_1+j*Nelx];    
    end
    
    smooth = intersect(smooth,crack_notch);

%% Filtro topo

VM_stress_min_3 = 1.3*(mean(nonzeros(VM_stress)));

smooth3 = 0;

   for i= 1:nel  
     
       if VM_stress(i) < VM_stress_min_3  
         smooth3 = [smooth3;i];
       else
       end
   end
   
   smooth3= unique(nonzeros(smooth3));
 
   Fnode3 = find(coord(:,2)== (floor(Lx*10/3))/10 & coord(:,3)==Ly); % find central node
   Fnode4 = find(coord(:,2)== Lx - ((floor(Lx*10/3))/10) & coord(:,3)==Ly); % find central node
  
   elemlod_3 = find(inci(:,5) == Fnode3);
   elemlod_4 = find(inci(:,6) == Fnode4);    
    
    crack_notch3 = [elemlod_3: elemlod_4]; 
    
    for j = 1:2
    crack_notch3 = [crack_notch3,crack_notch3-(j*Nelx)];    
    end
    
    smooth3 = intersect(smooth3,crack_notch3);
    
    smooth1 = nonzeros(union(smooth,smooth3));

    
%% Filtro geral
    
   %VM_stress_min_2 = 0.2*(mean(nonzeros(VM_stress)));
   VM_stress_min_2 = 0.1*(mean(nonzeros(VM_stress)));
   
   smooth2 = 0;

 for i= 1:nel  
     
       if VM_stress(i) < VM_stress_min_2  
         smooth2 = [smooth2;i];
       else
       end
 end   
 
 smooth = nonzeros(union(smooth1,smooth2));

Xnew(smooth) = x_min; 



    
end