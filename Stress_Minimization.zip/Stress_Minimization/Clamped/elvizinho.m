% Programa function para c�lculo de elementos vizinhos
% Unicamp
% Renato Picelli Sanches (12/03/12)

% side(nel,3) = [  N�mero dos elementos  |  Quantidade de elementos vizinhos de lado | ... 
%                   ... Quantidade de elementos vizinhos de canto ]
% se o elemento possui 3 ou menos vizinhos de lado, ele se encontra na borda da estrutura

% elside(nel,5) = [  N�mero dos elementos  |  Elementos vizinhos ( ele1, ele 2, ele3 , ele4) ]

function [side,elside] = elvizinho(nel,conect,noconect,Xnew)

% Iniciando a matriz side e elside
side = zeros(nel,3);
elside = zeros(nel,5);

% Declarando o n�mero dos elementos na primeira coluna de side e elside
side(:,1) = conect(:,1);
elside(:,1) = conect(:,1);


% Inicia o loop para verifica��o dos elementos vizinhos
for i = 1:nel
    
    % Inicia os contadores
    cont = 0;         % N�mero de elementos vizinhos de lado
    cont_canto = 0;   % N�mero de elementos vizinhos de canto
    aux_elside = 0;   % Auxiliar para aloca��o do vizinho de lado
    
    for j = 2:5  % (j = n� do elemento i analisado)
        
        % no = n� j do elemento i
        no = conect(i,j);
        
        for k = 2:5  % (k = conectividade do n� j)
            
            %Se a conectividade de do n� j � diferente de i e de 0 e o elemento i existe
           
            if ((noconect(no,k) ~= i) && (noconect(no,k) ~= 0) && (Xnew(noconect(no,k),1)==1));
                
                % Inicia o contador de n�s compartilhados entre elementos
                nocomp = 0;
                
                for l = 2:5  %(l = conectividade do elemento i)
                    for m = 2:5  %(m = conectividade do elemento vizinho que compartilha o n� 'no' com o elemento i)
                        if (conect(i,l) == conect(noconect(no,k),m));  %Se o elemento i tem �ndice de conectividade igual ao elemento vizinho que compartilha o n� 'no'
                            nocomp = nocomp+1;  %Indica n�s compartilhados entre o elemento de conect 'i' e 'm'
                        end
                    end
                end
                
                %Se os elementos compartilham 2 n�s, eles s�o vizinhos de lado
                if (nocomp == 2);
                    cont = cont+1;  %Contador de elementos vizinhos
                    
                    % Se o elemento vizinho ainda n�o foi computado
                    if (length(find(elside(i,2:5) == noconect(no,k))) ~= 1)
                        aux_elside = aux_elside+1;
                        % Armazena o elemento vizinho
                        elside(i,aux_elside+1) = noconect(no,k);
                    end
                    
                end
                
                %Se os elementos compartilham apenas um n�, eles s�o vizinhos de canto
                if (nocomp == 1);
                    cont_canto = cont_canto+1;  %Contador de elementos vizinhos
                end
                
            end
        end
    end
    
    %Escrevendo o n�mero de elementos vizinhos de lado do elemento i
    side(i,2) = cont/2;
    
    % N�mero de elementos vizinhos de canto do elemento i
    side(i,3) = cont_canto;
    
end


end
