%% Norma p - Holmberg et al 2013  

function [SIGMAG_PN,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM]=P_Norm(nel,GLOBAL_STRESS,VM_stress,Pn_factor)
    
SIGMAG_PN = ((sum(VM_stress.^Pn_factor)))^(1/Pn_factor);

%% Derivda da norma em relacao a tensao de von Mises (termo 1)  d(Sigma PN/ Sigma VM)

D_SIGMAG_PN_SIGMA_VM =((sum(VM_stress.^Pn_factor))^((1/Pn_factor)-1))*((VM_stress.^(Pn_factor-1)));
%D_SIGMAG_PN_SIGMA_VM =(sum(VM_stress.^(Pn_factor-1)))*((VM_stress.^(Pn_factor-1)));
%% Derivada de SIGMA_VM em relacao as 3 componentes das tensoes (sigma_x, sigma_y, tau_xy)

   D_SIGMA_VM(1,:) =((GLOBAL_STRESS(1,:).*2)-(GLOBAL_STRESS(2,:).*1))./((VM_stress(:,1).*2)'); 
   D_SIGMA_VM(2,:) =((GLOBAL_STRESS(2,:).*2)-(GLOBAL_STRESS(1,:).*1))./((VM_stress(:,1).*2)'); 
   D_SIGMA_VM(3,:) =(GLOBAL_STRESS(3,:).*3)./((VM_stress(:,1))');

end