% Function for centroids matrix evaluation and elements areas

% center = [ Xi | Yi ]

function [center,elarea] = centroids(nel,coord,inci)

% Calculating centroids
% Initializing centroids matrix
center = zeros(nel,2);

for i = 1:nel
    
    % Maximum coordinate X of element i
    xmax = max([coord(inci(i,2),1) coord(inci(i,3),1) coord(inci(i,4),1) coord(inci(i,5),1)]);
    % Minimum coordinate X of element i
    xmin = min([coord(inci(i,2),1) coord(inci(i,3),1) coord(inci(i,4),1) coord(inci(i,5),1)]);
    % Maximum coordinate Y of element i
    ymax = max([coord(inci(i,2),2) coord(inci(i,3),2) coord(inci(i,4),2) coord(inci(i,5),2)]);
    % Minimum coordinate Y of element i
    ymin = min([coord(inci(i,2),2) coord(inci(i,3),2) coord(inci(i,4),2) coord(inci(i,5),2)]);
    
    % X component of element i centroid
    dx = (xmax+xmin)/2;
    % Y component of element i centroid
    dy = (ymax+ymin)/2;
    
    % Centroids matrix
    center(i,1) = dx;
    center(i,2) = dy;
    
end

% Calculating element areas with regular mesh

% X dimension
Xc = coord(inci(1,3),1)-coord(inci(1,2),1);
% Y dimension
Yc = coord(inci(1,4),2)-coord(inci(1,3),2);

% Elements area
elarea = Xc*Yc;


end