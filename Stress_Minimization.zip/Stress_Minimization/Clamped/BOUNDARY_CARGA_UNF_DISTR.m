%function [elements_boundary,Fpressure]= BOUNDARY_CARGA_UNF_DISTR(VETOR_MALHA,inci,coord,Conectivity,crust,elside,Local_Carga,Po,A);
function [elements_boundary,Fpressure]= BOUNDARY_CARGA_UNF_DISTR(CORDENADAS_X,all_nodes_x0,VETOR_MALHA,inci,coord,Conectivity,crust,elside,Local_Carga,Po,A);

%% Identifica��o dos elementos do contorno (carga uniformemente distribuida)

clear elements_boundary

%% Carga Uniformemente Distribuida

% all_nodes_x0 = find(coord(:,3)==0);
% 
% for nos=1:size(coord,1)
%     for elemx0=1:size(all_nodes_x0,1)
%      if coord(nos,1)==all_nodes_x0(elemx0,1)
%      coord_X_ZEROS(elemx0,:)=coord((all_nodes_x0(elemx0)),1:3);
%      else
%      end
%     end
% end
% 
% CORDENADAS_X=coord_X_ZEROS(:,2);


elements_boundary=0;
%CONJUNTO_COLUNA_ELEM_Xi=0;

for elemx0_i=1:size(all_nodes_x0,1)
    
%conjunto de elementos cuja coordenada X = x_i
   CONJUNTO_COLUNA_coord_Xi = find(coord(:,2)==CORDENADAS_X(elemx0_i));
   CONJUNTO_COLUNA_ELEM_Xi=0;
 for   j=1:size(CONJUNTO_COLUNA_coord_Xi,1)
     
    CONJUNTO_COLUNA_ELEM_5=find(Conectivity(:,5)==CONJUNTO_COLUNA_coord_Xi(j)); 
   
    CONJUNTO_COLUNA_ELEM_Xi=nonzeros([CONJUNTO_COLUNA_ELEM_Xi;CONJUNTO_COLUNA_ELEM_5]); 
  
 end

  [CONJUNTO_COLUNA_ELEM_Xi_new] = intersect(CONJUNTO_COLUNA_ELEM_Xi,crust);
    
   if Local_Carga==1
    element_max=max(CONJUNTO_COLUNA_ELEM_Xi_new);
    elements_boundary=[elements_boundary;element_max];   
   elseif Local_Carga==2
    element_min=min(CONJUNTO_COLUNA_ELEM_Xi_new);
    elements_boundary=[elements_boundary;element_min];
   end
 end
   elements_boundary=(nonzeros(elements_boundary));

   
  
 

   
%% pressao

% Identifica��o dos elementos do contorno (carga de press�o)

%  elements_boundary= crust;

%% Assembly das cargas distribu�das 

% INICIALIZA��O DAS VARI�VEIS
% 
 ndof= 2; % grau de liberdade por n� %Estrutural: ndof=2; T�rmica: ndof=1
 nnel = 4;%numero de n�s por elemeto: quad = 4
 numnos = size(coord,1);% numero de n�s
 sdof=ndof*numnos; % numero de equa��es sem eleiminar as restricoes  
 edof=ndof*nnel; % numero de DOFs por elemento termica: quad = 1*4 ;estrutural: quad = 2*4

 Fpressure = zeros(sdof,1); % inicializa��o vetor de carga distribuida devido a press�o

 id= reshape(1:ndof*numnos,ndof,numnos);
 

Nelx = VETOR_MALHA(1,4);

%% Carga de Press�o  

  limite_superior = size(elements_boundary,1);
  
 for i_distr=1:limite_superior      

 elside_new=(nonzeros(elside(elements_boundary(i_distr,1),2:5)))';

 size_elside=size(elside_new,2); 
 
 el_Face2=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))-1);
 if el_Face2~=0; Face2=0;else Face2=1;end;
 
 el_Face3=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))+1);
 if el_Face3(1,:)~=0;Face3=0;else Face3=-1;end;

 el_Face4=intersect(elside_new(1,1:size_elside),(elements_boundary(i_distr))+Nelx);
 if el_Face4(1,:)~=0;Face4=0;else Face4=-1;end; 

 if (elements_boundary(i_distr))-Nelx<=0;down=0;else down=(elements_boundary(i_distr))-Nelx;end;
 el_Face1=intersect(elside_new(1,1:size_elside),down);
 if el_Face1(1,:)~=0;Face1=0;else Face1=1;end;

    
 %Face2=0;Face3=0;   
    
Npress = [Face2,Face1,Face3,Face1,Face3,Face4,Face2,Face4];          
        
 Fpressure_e = (1/2)*Po*A*Npress;         
 
     
    NO_1 = inci((elements_boundary(i_distr,1)),3);
    NO_2 = inci((elements_boundary(i_distr,1)),4);
    NO_3 = inci((elements_boundary(i_distr,1)),5);
    NO_4 = inci((elements_boundary(i_distr,1)),6);
    
    % Posi��o na Matriz de Rigidez

     pos=[id(1,NO_1) id(2,NO_1) id(1,NO_2) id(2,NO_2) id(1,NO_3) id(2,NO_3) id(1,NO_4) id(2,NO_4)]; %

     
    for lin_Fe = 1:8 %
        lin_FG = pos(lin_Fe);
          if any(lin_FG);
             Fpressure(lin_FG) = Fpressure(lin_FG)+Fpressure_e(lin_Fe);
          end
    end
  
 end 

end