function[LAMBDA] = Variable_Lambda(coord,inci,Kg,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM,D,B,freedofs,fixeddofs)

nnos = size(coord,1); 
nel = length(inci(:,1)); 
id = reshape(1:2*nnos,2,nnos);

KLAMBDA = zeros(2*nnos,1);
LAMBDA = zeros(1,2*nnos);

for iel= 1:nel
    
  termo1_elem = D_SIGMAG_PN_SIGMA_VM(iel,1)*(D_SIGMA_VM(1:3,iel))'*D*B;
      
      pos=[id(1,inci(iel,3)) id(2,inci(iel,3)) id(1,inci(iel,4)) id(2,inci(iel,4)) id(1,inci(iel,5)) id(2,inci(iel,5)) id(1,inci(iel,6)) id(2,inci(iel,6))]; %
           
      for lin_Fe = 1:8 %
        lin_FG = pos(lin_Fe);
          if any(lin_FG);
             KLAMBDA(lin_FG) = KLAMBDA(lin_FG) + termo1_elem(lin_Fe);
          end
      end 
end


LAMBDA(freedofs) = Kg(freedofs,freedofs)\KLAMBDA(freedofs);
  
end



