function [UX,UY] = plotstress(coord,inci,GLOBAL_VM,U)

 %%   ESTRUTURA DEFORMADA  
  figure('Name','ESTRUTURA DEFORMADA','NumberTitle','off');
  
  Lxmax =max(coord(:,2));
  Lxmay =max(coord(:,3));
  Lmax=max(Lxmax,Lxmay);
  
  escala=0.2*Lmax/max(abs(U));
  
    patch('Faces',inci(:,3:6),'Vertices',coord(:,2:3),'FaceColor','b');    
    hold on
       
    patch('Faces',inci(:,3:6),'Vertices',[coord(:,2)+escala*U(1:2:end,1) coord(:,3)+ escala*U(2:2:end,1)],'FaceVertexCData',[1 1 1],'FaceColor','flat');
   
    camlight left
    colormap('jet');
    lighting gouraud   
    hold off     
        
 %%   PLOTAGEM DAS TENS�ES 

    figure('Name','STRESS','NumberTitle','off');  
    patch('Faces',inci(:,3:6),'Vertices',coord(:,2:3),'FaceVertexCData',GLOBAL_VM,'FaceColor','flat');
    colormap('jet');
    lighting gouraud 
    colorbar
  
%% Deslocamentos

   UX =U(1:2:end,1);
   UY =U(2:2:end,1);
   
  end %end function 
  
