% MAIN STRESS MINIMIZATION PROGRAM
% 2019/10/25 
% Gisele Lucas Garcez 
% RA 181463

clear all
close all
clc

%% GEOMETRIC DATA

Lx = 6;Ly = 2;Lz = 1;Nelx = 300;Nely = 100;F = 0; % Arco

Local_Carga = 1; % topo=1; base=2

%% SIMP parameters

x_min = 0.001; % design variable 

p = 3; % penalization 

Pn_factor = 5;

%% MESH GENERATOR

[coord,conectivity] = quad4(Lx,Ly,Nelx,Nely);

% plot mesh
%plotmalha(coord,conectivity,1)

%% MATERIAL PROPERTIES
 g = 9.81;

   E  = 210e9; ni = 0.30; rho = 7870;
  
 sigma_yield = 350e6; % AISI 1018 carbon steel
 sigma_restr = 350e6; % AISI 1018 carbon steel
 
[mat_prop,mat,inci] = mat_properties(conectivity,E,ni,rho);
%%  Defini��o do par�metros de otimiza��o

 V_frac = 0.20;       % Porcentagem de volume final

 ER = 0.03;          % Porcentagem de remo��o de Material a cada itera��o, o livro manda utilizar esse valor no soft-kill,  
 AR_max = 0.03;      % Porcentagem de adi��o de Material

%r_min= 0.06;           % Raio minimo do filtro
r_min= 0.08;           % Raio minimo do filtro

%tau= 1/100;     % Precis�o do crit�rio de converg�ncia (Mean Compliance)
tau = 0.1/100;     % Precis�o do crit�rio de converg�ncia (Mean Compliance
%tau = 0.01/100;     % Precis�o do crit�rio de converg�ncia (Mean Compliance
N = 5;              % Numero de itera��es para o c�lculo do erro


V_inicial = Lx*Ly*Lz;            % Volume do dom�nio
V_elem = Lx*Ly*Lz/(Nelx*Nely);   % Volume Elemental - Todos os elementos tem tamanhos iguais
nel = length(inci(:,1));               % Numero de Elementos
elem_list = (1:nel);             % Lista dos Elementos % Vetor linha com a lista de elementos
V_final = V_frac * V_elem * nel; % Volume final

%% Carga distribuida

PP_calc = - rho*g*V_frac;

A = (Lx/Nelx)*Lz % �rea do elemento 

%Po = 5.2e6;
%Po = 5.1e6;
Po = 5.0e6;

%Po = (rho*g*V_inicial*2)/(A*Nelx) %  peso proprio INICIAL N/m
%Po = (rho*g*V_inicial)/(A*Nelx) % 100% do peso proprio INICIAL N/m
%Po = (rho*g*V_inicial*0.5)/(A*Nelx) % 50% do peso proprio INICIAL N/m
%% BOUNDARY CONDITIONS AND LOAD CASES

% caso = 1: viga MBB
% caso = 2: viga engastada-livre, carga concendrada na extremidade

caso = 3;

[Forcas,alldofs,fixeddofs,freedofs,fixednodes]= BOUNDARY_CONDITIONS(caso,coord,Lx,Ly,Nelx,Nely,F);

%% Element Stiffness Matrix 

% i = 1  todos os elemenos s�o iguais
[Ke,Fpp_e] = elem_elast_quad(g,1,Lz,coord,conectivity,mat_prop);
[D,B] = DB (1,Lz,coord,conectivity,mat_prop);

%% Design Domain

[N_designD,node_N_designD,dof_designD] = design_domain(Lx,Ly,Nelx,inci,conectivity,coord,Forcas,caso);
%% Force Vector 

[Fg]=forces(Forcas,coord);

%% Force Vector Peso Pr�prio
 
[Fpp] = forces_carga_peso_proprio(coord,inci,Fpp_e);

 %% Force Vector Carga Unifomemente distribu�da
 
 VETOR_MALHA = [Lx,Ly,Lz,Nelx,Nely,F];
 
%% ANSYS OUTPUT

%ANSYS_OUTPUT(coord,inci,Forcas,fixednodes)

%%  Inicializa��o das vari�veis BESO

 V_obj = 1;
 ite = 0;
 error = 0.9999; V = 1;
 cond_volume = 0;
 nnos = length(coord(:,1));
 node_list =1:nnos;
 
 Xnew = ones(size(conectivity,1),1); % Todos os elementos s�o 1

% Xnew(3,1)= x_min;
 
 
 %% Filter H

[noconnect] = nodalconnect(nnos,conectivity); % Matriz Conectividade Nodal (encontra os elementos associados aquele n�)
[center,elarea] = centroids(nel,coord(:,2:3),conectivity);

 [H] = filterH(conectivity,elem_list,center,coord(:,2:3),r_min);
 
% %% Design Domain
% 
% [N_designD,node_N_designD,dof_designD] = design_domain(Lx,Ly,Nelx,inci,conectivity,coord,Forcas);
 
[CORDENADAS_X,all_nodes_x0] = CORDENADASX(coord);

%%  Inicio do processo de otimiza��o - BESO
tic 

 Xold = Xnew;  
 
[Fpress,elements_boundary,Xb,side,elside,crust,crust_inicial] = forces_carga_uniformemente_distribuida(CORDENADAS_X,all_nodes_x0,coord,inci,conectivity,Xnew,x_min,VETOR_MALHA,noconnect,Local_Carga,Po,A);

 
while (cond_volume == 0) || (error >= tau)
%% Assembly do peso_proprio = rho*vol*g % Com Penaliza��o da for�a 
   
  [Fpp] = Peso_Proprio_assembly(coord,inci,Fpp,Fpp_e,Xold,Xnew,x_min,p);  
 
  vol = ((size((find(Xnew==1)),1))/nel) * V_inicial;
   
  PP_calc = - rho*g*vol;
  Sum_PP = sum(Fpp); 
    
    
% Assembly Carga Uniformemente distribuida

 [Fpress,elements_boundary,Xb,side,elside,crust,crust_all] = forces_carga_uniformemente_distribuida(CORDENADAS_X,all_nodes_x0,coord,inci,conectivity,Xnew,x_min,VETOR_MALHA,noconnect,Local_Carga,Po,A);

 %% Atualiza��o das itera��es 
      
 ite = ite+1; 
          
 Xold = Xnew;   
    
 Xb_old = Xb;
      
%%  Atualiza��o da matriz de rigidez

[Kg] =Kassembly(coord,inci,Ke,Xnew,x_min,p);

%% Atualiza��o do vetor de For�a
   
   Ftotal =  Fg + Fpress;
 
%% solver

nnos = size(coord,1); 
U = zeros(2*nnos,1);% inicializa��o do vetor deslocamento

U(freedofs) = Kg(freedofs,freedofs)\Ftotal(freedofs);
U(fixeddofs)= 0;

%% von Mises Satress

[GLOBAL_STRESS,VM_stress] = von_Misses(U,coord,inci,mat_prop,Xnew,p);
Stress_max_ITE (ite,1) = max(VM_stress);   
% Plot von Mises
%[UX,UY] = plotstress(coord,inci,VM_stress,U);

%% P-Norm

[NORMA_P,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM] = P_Norm(nel,GLOBAL_STRESS,VM_stress,Pn_factor);

%[NORMA_P,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM] = P_Norm_Normalized(nel,GLOBAL_STRESS,VM_stress,Pn_factor);


% Adjoint Variable 

% Huang
 [LAMBDA] = Variable_Lambda(coord,inci,Kg,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM,D,B,freedofs,fixeddofs);

%  Xia e Xie 
%  [LAMBDA] = Variable_Lambda_Xie(coord,inci,Kg,VM_stress,GLOBAL_STRESS,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM,NORMA_P,D,B,Pn_factor,freedofs,fixeddofs);
 
%% Sensibility Min Stress

%% Sensibility Min Stress
if ite ==1
FD_MATRIX_OLD = zeros(8,nel);
else
    
FD_MATRIX_OLD = FD_MATRIX_NEW;
end

[alpha_e,alpha_e_loaded,Y,dY,Y_UKU,dY_UKU,UKU,FD_MATRIX_NEW] = sensibility_min_stress(ite,VETOR_MALHA,coord,inci,conectivity,U,Xnew,p,LAMBDA,Ke,Fg,NORMA_P,D_SIGMAG_PN_SIGMA_VM,D_SIGMA_VM,D,B,elements_boundary,Xb,Xb_old,elside,Po,A,Pn_factor,FD_MATRIX_OLD,V_elem,rho,g);

% disp( 'UKU'),disp(UKU)
  
%% Filtro Num�rico

[alphaS_loaded] = filterBEFSOH(nel,nnos,noconnect,elem_list,node_list,1,alpha_e_loaded,H);
[alphaS] = filterBEFSOH(nel,nnos,noconnect,elem_list,node_list,1,alpha_e,H);

alpha_e = (alpha_e - (min(alpha_e)))./((max(alpha_e))-(min(alpha_e)));
alpha_e_loaded = (alpha_e_loaded - (min(alpha_e_loaded)))./((max(alpha_e_loaded))-(min(alpha_e_loaded)));

%% Plot Sensitivity Number

ListSolid= find(Xnew==1);
plot_sensitNumber(coord,inci,Xnew,alphaS);

%% Estabiliza��o do Processo Evolucion�rio % Calculo a m�dia hist�rica

%Unloaded

    if ite==1; 
        alphaS_old = alphaS;
    else
         alphaS = (1/2)*(alphaS_old + alphaS);        
         alphaS_old = alphaS;
    end
  
 %Loaded

    if ite==1; 
        alphaS_old_loaded = alphaS_loaded;
    else
         alphaS_loaded = (1/2)*(alphaS_old_loaded + alphaS_loaded);        
         alphaS_old_loaded = alphaS_loaded;
    end
  % Gera sa�da Externa !!
%save('Sensibilidade.txt','alphaS','-ascii')     
%% Check do volume
    
    Vrec(ite) = size(find(Xnew==1),1) /nel; 
    Vrec_end = Vrec(end)  
    V(ite) = Vrec_end;    
      
 %% C�lculo do volume  Pag 23 Livro Xie 
    
        if (V(ite) - V_frac >= ER*V(ite));
            V(ite+1)=V(ite)*(1-ER);
        elseif (V(ite)-V_frac <= -ER*V(ite));
            V(ite+1)=V(ite)*(1+ER);
        elseif (abs(V(ite)-V_frac) < ER*V(ite));
            V(ite+1)=V_frac; cond_volume = 1;
        end
 
%save('V_Gisele.txt','V','-ascii') 

%% Ordena��o da Sensibilidade 

    [alphaS_ord,ord] = sort(alphaS,1,'descend');
    [alphaS_ord,ord_loaded] = sort(alphaS_loaded,1,'descend');
    
  %   [alphaS_ord,ord] = sort(alphaS,1,'ascend');   
%   Gera sa�da Externa !!
%save('Sensibilidade_ordenada_Gisele.txt','alphaS_ord','-ascii')  
   
   
%% Escolha dos elementos que ser�o retirados
    
    nath = round(V(ite+1)*length(elem_list));
    
    nath = round(nath/4)*4; % N�mero par de elementos removidos/adicionados
   
    % N�mero de elementos adicionados
    
    nadd = nath-length(nonzeros(Xnew(ord(1:nath)) == 1));
    nadd_loaded = nath-length(nonzeros(Xnew(ord_loaded(1:nath)) == 1));
    
    % Raz�o de adic�o de (Addition Ratio)
    AR = nadd/nel;
    AR_loaded = nadd_loaded/nel; 
 
%% Dependent Atualiza��o do vetor binario que indica se o elemento � s�lido (1) ou vazio (0)

      [Xnew] = updatematBESO_dependent(AR,AR_loaded,AR_max,ord,ord_loaded,Xnew,elem_list,nath,ite,V,x_min);

%%
%
%[Xnew] = updatematBESO(AR,AR_max,ord,Xnew,elem_list,nath,ite,V,x_min);
%

% Gera sa�da Externa !!
%save('Xnew_Gisele.txt','Xnew','-ascii')  
%%  Atualiza��o da matriz de rigidez

% [Kg] =Kassembly(coord,inci,Ke,Xnew,x_min,p);

%% Compliance

    Compliance(ite)=sum(alphaS);
    
    SUM_ALPHA(ite)=sum(alphaS);
    P_norma_stress(ite,1) = NORMA_P;
    
    % Gera sa�da Externa !!
save('Sum_Apha_e_Gisele.txt','Compliance','-ascii')        
    
%% Criterios de parada do algoritmo CL�SSICO

%     if ite>=2*N
%         error=abs(sum(Compliance(ite-N+1:ite))-sum(Compliance(ite-N*2+1:ite-N)))...
%             /sum(Compliance(ite-N+1:ite));
%     end

%% Criterios de parada do algoritmo MIN STRESS
  
Max_Sigma_VM (ite,1)= max(VM_stress);

    if ite>=(2*N)
         error = abs(sum(Max_Sigma_VM(ite-N+1:ite))-sum(Max_Sigma_VM(ite-N*2+1:ite-N)))...
             /sum(Max_Sigma_VM(ite-N+1:ite));
    end            
    %% Apresenta��o das informa��o da itera��o
    
    disp([' It.: ' sprintf('%4i',ite) ' Obj.: ' sprintf('%6.4e',sum(alphaS)) ...
        ' Vol.: ' sprintf('%6.3f',V(ite+1)) ' error.: ' sprintf('%3.2f %%',error*100)])
    
    %% Plot da estrutura em cada itera��o
       
    z=reshape(Xnew(end:-1:1),Nelx,Nely); z = z(end:-1:1,:);
    f1 = figure(1);colormap(gray); imagesc(-z'); axis equal; axis tight; axis off;
    pause(0.001)
  
end

%% Plot Sensitivity Number final

plot_sensitNumber_final(coord,inci,Xnew,alphaS);

toc
%% Plot Final von Mises 
 %VM_stress(N_designD)=0;
 plotstress_final(coord,inci,elem_list,VM_stress,N_designD)
 plot_stress_3(coord,inci,Xnew,VM_stress)
%%  Plot P-norma and volume fraction
P_norma_stress = P_norma_stress/10^6;
plot_Pnorm (P_norma_stress,ite,V);

%% Plot Compliance and Volume fraction

% plot_Compliance(SUM_ALPHA,ite,V);
plot_Compliance(Compliance,ite,V);

%%  Final Informations

NORMA_P = NORMA_P

C =  ((Ftotal(freedofs))')*(U(freedofs))

disp('Tens�o em MPa')
Max_Sigma_VM = max(VM_stress)/(10^6)

% Plot carga Distribuida Final
plot_carga_distr(inci,coord,Xold,elements_boundary,VETOR_MALHA);
%%
%% Extra Plots

%plot_Max_VM_stress_2 (Stress_max_ITE,ite,sigma_restr);
plot_Max_VM_stress_3 (Stress_max_ITE,ite,sigma_yield);
plot_Pnorm_sigma_restr(P_norma_stress,ite,sigma_yield);

%plot_DSigmaPN_sigma_restr(D_Norma_max,ite,sigma_yeld);


%