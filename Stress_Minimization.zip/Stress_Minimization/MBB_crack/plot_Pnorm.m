function  plot_Pnorm (P_norma_stress,ite,V,Pn_factor)

figure('Name','P-norm Stress and Volume fraction ','NumberTitle','off');
%figure('Name','','NumberTitle','off');


if Pn_factor==6
[AX,H1,H2]=plotyy(1:(ite-1),P_norma_stress(1:(end-1)),1:(ite-1),V(2:(end-1))*100);
else
[AX,H1,H2]=plotyy(1:ite,P_norma_stress,1:ite,V(2:end)*100);
end

set(AX,{'ycolor'},{'k';'k'}); legend('P-norm stress','Volume fraction')
set(get(AX(1),'Ylabel'),'String','P-norm stress (MPa)');
set(get(AX(2),'Ylabel'),'String','Volume fraction (\it V / V_i )');

set(AX(1),'YLim',[0.95*min(P_norma_stress) 1.05*max(P_norma_stress)])
set(AX(1),'YTick',linspace(0.95*min(P_norma_stress),1.05*max(P_norma_stress),11))
set(AX(2),'YLim',[0 100]); set(AX(2),'YTick',0:10:100);

%xlabel('Iteration'); title('\fontsize{13}P-norm Stress and Volume fraction')
set(H1,'LineStyle','-','Marker','*');set(H2,'LineStyle','-','Marker','d');

grid on

 tiy = get(gca,'ytick')';
 set(gca,'yticklabel',num2str(tiy,'%.2f'))

 ft = 'Times';
fsz = 16;       

set(findall(gcf,'type','text'), 'FontSize', fsz, 'Color', 'k','FontName', ft)
set(gca,'FontSize', fsz, 'FontName', ft)

end